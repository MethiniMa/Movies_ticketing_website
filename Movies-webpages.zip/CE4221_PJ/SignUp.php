<?php
session_start();
    include("connection.php");
    include("function.php"); 

   if($_SERVER['REQUEST_METHOD'] == "POST")
   {
      $username = $_POST['username'];
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $ps = $_POST['ps'];
      
      
      if(!empty($username) && !empty($email) && !empty($phone))
      {
        if(!empty($ps)){
          if(is_numeric($phone))
          {
            $sql = "INSERT INTO userlist (UserName, Email, Phone, PS) VALUES ('$username','$email','$phone','$ps')";

            mysqli_query($conn,$sql);

            header("Location: LoginPage.php");
            die;
          }else{
            echo "Please fill out correct form of phone number!";
          }
        }
      }else{
        echo "Please fill out all information!";
      }
   }

?>

<!DOCTYPE html>
<html>
    <head>
       
        <title>SignUp.com</title>
        <style>
            body{
                background: linear-gradient(black,darkred);
            }
            .SignUp-box{
                width: 280px;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%,-50%);
                color: white;
            }
            .SignUp-box h1{
                float: left;
                font-size: 40px;
                border-bottom: 6px solid #e0e7e7;
                margin-bottom: 50px;
                padding: 14px 0;
            }
            .textbox{
                width: 100%;
                overflow: hidden;
                font-size: 20px;
                border-bottom: 1px solid #e0e7e7;
                margin: 8px 0;
                padding: 8px 0;
            }
            .bt{
                width: 100%;
                background: none;
                border:2px solid  #e0e7e7;
                color: white;
                padding: 5px;
                font-size: 18px;
                cursor: pointer;
                margin: 12px 0;
            }
        </style>
    </head>

    <body>

        <div class="SignUp-box">
            <h1 style="font-family: Arial, Helvetica, sans-serif;"><b>Sign Up</b></h1>
            
            <div class="textbox">

             <form  method="POST">

                <b>Please enter Username</b><br><br>
                <input type="text" name="username" id="username" placeholder="User Name" required><br><br>
                <b>Please enter your Email: </b><br><br>
                <input type="email" name="email" id="email" placeholder="Email" required>
                <br><br>
                <b>Please enter your Phone number: </b><br><br>
                <input type="text" name="phone" id="phone" placeholder="Phone Number" required>
                <br><br>
                <b>Please enter your password: </b><br><br>
                <input type="password" name="ps" id="ps" placeholder="Password" required>
                <a href="LoginPage.php">
                <p style="color: white;"><u> Log in</u></p>
                </a>

                <input type="submit" class="bt" id="Signup" value="Sign Up">
             </form>
            </div>

        </div>
    </body>
</html>