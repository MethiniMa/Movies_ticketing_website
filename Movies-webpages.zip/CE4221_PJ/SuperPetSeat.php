<?php
session_start();
include("connection.php");
include("function.php"); 
$userData = check_login($conn);

?>

<!DOCTYPE html>
<html>

<head>
    <title>AUBookingSeat.com</title>
   
    <style>

@import url(https://fonts.googleapis.com/css?family=Josefin+Sans:400,700,400italic|Megrim);
            		*{
			box-sizing: border-box;
		}
		body {
            background: linear-gradient(black,darkred,black);
			font-family: "Josefin Sans";
		}
		.event{
			border-radius: 4px;
			width: 1000px;
			height: 450px;
            margin: 40px auto 0;
		}
		.event-side{
			padding: 10px;
			border-radius: 4px;
			float: left;
			height: 100%;
			width: calc(15% - 1px);
			box-shadow: 1px 2px 2px -1px #888;
			background: url('Image/Superpetbg.jpg');
			z-index: 1000;
			border-bottom-right-radius: 10px;
			border-top-right-radius: 10px;
			position: relative;
			overflow: hidden;
			font-size: 0.8em;
			text-align: right;
		}

		.to {
			display: block;
			position: relative;
			left: -25%;
		}
		.cut-out {
			border-radius: 1000px;
			width: 100%;
			height: 40%;
			display: block;
			position: absolute;
			left: -60%;
			top: 25%;
			background: rgb(255, 252, 252);
			box-shadow: inset -1px 2px 2px -1px #888
		}
		.dotted-line-separator {
			right: -2px;
			position: absolute;
			background: #fff;
			width: 5px;
			top: 8px;
			bottom: 8px;
		}
		.dotted-line-separator .line {
			/*border-right: 1px dashed #ccc;*/
			transform:rotate(90deg);
		}
		.dotted-line-separator .line:after {
			content: "| | | | | | | | | | | | | | | | | | | | | | | | | | |";
			overflow: hidden;
			display: block;
			position: relative;
			left: 1px;
			height: 90%;
			margin: 5px 0;
			display: block;
			color: rgba(204, 204, 204, 0.5);
		}
		.event-body {
			border-radius: 4px;
			float: left;
			height: 100%;
			width: 85%;
			box-shadow: 0 2px 2px -1px #888;
			background: url('Image/Superpetbg.jpg');
			padding-right: 10px;
			border-bottom-left-radius: 10px;
			border-top-left-radius: 10px; 
		}
		.event-title, .event-name, .event-details{
			float: left;
			width: 54%;
			padding: 10px;
		}
		.event-title, .event-name {
			border-bottom: 1px solid gray;
		}
		.event-name, .event-details {
			height: 30%;
			line-height: 24px;
		}
		.event-title {
			height: 40%;
		}
		.event-title span{
			font-size: 0.5em;
			text-transform: uppercase;
			color: #888;
		}
		.event-title h3 {
			margin: 0;
		}
		.event-image{
			width: calc(46% - 20px);
			height: calc(100% - 20px);
			margin: 10px;
			float: left;
			overflow: hidden;
            text-align: center;
		}
		.image {
			display: block;
			height: 100%;
            width: 100%;
            background: url('Image/Superpetbg.jpg');
            background-repeat: no-repeat;
            background-size: cover;
		}

    
   
    body {
    font-family: "Montserrat", sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    background: linear-gradient(black,#722F37,rgb(107, 0, 0),black);
    color: #fff;
    margin: 0;
    }

    * {
    font-family: "Montserrat", sans-serif !important;
    box-sizing: border-box;
    }

    .movie-container {
    margin: 20px 0px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column
    }
   
    .movie-container select {
    appearance: none;
    -moz-appearance: none;
    -webkit-appearance: none;
    border: 0;
    padding: 5px 15px;
    margin-bottom: 40px;
    font-size: 14px;
    border-radius: 5px;
    }

    .screen {
    background-color: white;
    height: 70px;
    width: 100%;
    margin: 15px 0;
    transform: rotateX(-45deg);
    box-shadow: 0 3px 10px rgba(255,255,255,0.7);
    }

    .container {
    perspective: 1000px;
    margin: 40px 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    float: left;
    }

   .fuselage {
    border-right: 5px solid #d8d8d8;
    border-left: 5px solid #d8d8d8;
    }
   
    ol{
    list-style :none;
    padding: 0;
    margin: 0;
    }

    .row {
    display: flex;
    align-items: center;
    justify-content: center;
    }

   .seats {
     display: flex;
     flex-direction: row;
     flex-wrap: nowrap;
     justify-content: flex-start;  
   }

   .seat {
    background-color: #444451;
    height: 40px;
    width: 30px;
    margin: 8px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    }
   
   .seat2 {
    display: flex;
    flex: 0 0 14.28571428571429%;
    padding: 5px;
    position: relative;   
    }

    .selected {
    background-color: #0081cb;
    }

    .occupied {
    background-color: #fff;
    }

    .seat:not(.occupied):hover {
    cursor: pointer;
    transform: scale(1.2);
    }

    .showcase .seat:not(.occupied):hover {
    cursor: default;
    transform: scale(1); 
    }
   
    .showcase {
    display: flex;
    justify-content: space-between;
    list-style-type: none;
    background: rgba(0,0,0,0.1);
    padding: 5px 10px;
    border-radius: 5px;
    color: #777;
    }
   
    .showcase li {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 10px;
   }
   
    .showcase li small {
    margin-left: 2px;
    }
   
    .row {
    display: flex;
    align-items: center;
    justify-content: center;
    }
   
    p.text {
    margin: 20px 0;
    }
   
   
    p.text span {
    color: #0081cb;
    font-weight: 600;
    box-sizing: content-box;
    }
   
    .credits a {
    color: #fff; 
    }
   </style>
   
    </head>
    <body>

    <div class="movie-container">
        <p style="color: white; font-size: 30px; padding-top:25px;">250 per Seat</p>
   
        <div class="container">
       
        <div class="screen"></div>
        <ol class="cabin fuselage">
             <li class="row row--1">
               <ol class="seats" type="A">
               <li class="seat">
                   <input type="checkbox" class="checkbox" id="1F" value="1F">
                   <label for="1F">1F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="2F" value="2F">
                   <label for="2F">2F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="3F" value="3F">
                   <label for="3F">3F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="4F" value="4F">
                   <label for="4F">4F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="5F" value="5F">
                   <label for="5F">5F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="6F" value="6F">
                   <label for="6F">6F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="7F" value="7F">
                   <label for="7F">7F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="8F" value="8F">
                   <label for="8F">8F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="9F" value="9F">
                   <label for="9F">9F</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="10F" value="10F">
                   <label for="10F">10F</label>
                 </li>
                
                 
               </ol>
             </li>
             <li class="row row--2">
               <ol class="seats" type="A">
               <li class="seat">
                   <input type="checkbox" class="checkbox" id="1E" value="1E">
                   <label for="1E">1E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="2E" value="2E">
                   <label for="2E">2E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="3E" value="3E">
                   <label for="3E">3E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="4E" value="4E">
                   <label for="4E">4E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="5E" value="5E">
                   <label for="5E">5E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="6E" value="6E">
                   <label for="6E">6E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="7E" value="7E">
                   <label for="7E">7E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="8E" value="8E">
                   <label for="8E">8E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="9E" value="9E">
                   <label for="9E">9E</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="10E" value="10E">
                   <label for="10E">10E</label>
                 </li>
                 
               </ol>
             </li>
             <li class="row row--3">
               <ol class="seats" type="A">
               <li class="seat">
                   <input type="checkbox" class="checkbox" id="1D" value="1D">
                   <label for="1D">1D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="2D" value="2D">
                   <label for="2D">2D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="3D" value="3D">
                   <label for="3D">3D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="4D" value="4D">
                   <label for="4D">4D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="5D" value="5D">
                   <label for="5D">5D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="6D" value="6D">
                   <label for="6D">6D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="7D" value="7D">
                   <label for="7D">7D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="8D" value="8D">
                   <label for="8D">8D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="9D" value="9D">
                   <label for="9D">9D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="10D" value="10D">
                   <label for="10D">10D</label>
                 </li>
                
               </ol>
             </li>
             <li class="row row--4">
               <ol class="seats" type="A">
               <li class="seat">
                   <input type="checkbox" class="checkbox" id="1D" value="1D">
                   <label for="1D">1D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="2D" value="2D">
                   <label for="2D">2D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="3D" value="3D">
                   <label for="3D">3D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="4D" value="4D">
                   <label for="4D">4D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="5D" value="5D">
                   <label for="5D">5D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="6D" value="6D">
                   <label for="6D">6D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="7D" value="7D">
                   <label for="7D">7D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="8D" value="8D">
                   <label for="8D">8D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="9D" value="9D">
                   <label for="9D">9D</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="10D" value="10D">
                   <label for="10D">10D</label>
                 </li>
                 
               </ol>
             </li>
             <li class="row row--5">
               <ol class="seats" type="A">
               <li class="seat">
                   <input type="checkbox" class="checkbox" id="1B" value="1B">
                   <label for="1B">1B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="2B" value="2B">
                   <label for="2B">2B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="3B" value="3B">
                   <label for="3B">3B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="4B" value="4B">
                   <label for="4B">4B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="5B" value="5B">
                   <label for="5B">5B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="6B" value="6B">
                   <label for="6B">6B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="7B" value="7B"> 
                   <label for="7B">7B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="8B" value="8B">
                   <label for="8B">8B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="9B" value="9B">
                   <label for="9B">9B</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="10B" value="10B">
                   <label for="10B">10B</label>
                 </li>
                
               </ol>
             </li>
             <li class="row row--6">
               <ol class="seats" type="A">
               <li class="seat">
                   <input type="checkbox" class="checkbox" id="1A" value="1A">
                   <label for="1A">1A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="2A" value="2A">
                   <label for="2A">2A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="3A" value="3A">
                   <label for="3A">3A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="4A" value="4A">
                   <label for="4A">4A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="5A" value="5A">
                   <label for="5A">5A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="6A" value="6A">
                   <label for="6A">6A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="7A" value="7A">
                   <label for="7A">7A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="8A" value="8A">
                   <label for="8A">8A</label>
                 </li>
                 <li class="seat">
                   <input type="checkbox" class="checkbox" id="9A" value="9A">
                   <label for="9A">9A</label>

                   </li><li class="seat">
                   <input type="checkbox" class="checkbox" id="10A" value="10A">
                       <label for="10A">10A</label>
                     </li>
                
                 
               </ol>
             </li>
           
           </ol>
         
           <div class="print-values">
            <p id="valueList"></p>
          </div>

          <div class="print-no.seat">
            <p id="countList"></p>
          </div>

          <div class="print-cost">
            <p id="totalList"></p>
          </div>

          <a href="payment.php">
            <input type="button" id="button1" value="Confirm" 
            style="border-radius:14px; background-color:gold; width: 100px; height: 50px;"></button>
          </a><br>

        </div>
    </div>

    <div class='event'><br>
            <div class='event-side'>
                <div class='cut-out'></div>
            </div>
            <div class='event-body'>
              <div class='event-image'><a href='#'><span class='image'></a></div>
              <div class="event-name">
                <h2 style="font-size: 44px; color: white;">AU Cinema</h2>
              </div>
              <div class="event-title">
                <h2 style="font-size: 34px; color: white;">DC League of Super-Pets</h2>
                <p style="color: white;">105 mins | Adventure/Sci-f</p>
              </div>
              <div class="event-details">
                <h3 style="color: white;">SEAT:</h3>
                <div class="print-cost">
                        <h2 id="seatinfo" style="color: white;"></h2>
                        </div> 
              </div>
            </div>
          </div>
       
       
          <br>
          <br>
          <br>
          <br>
          <br>
   
        <script src="s.js"></script> 
       
       </body>
    </html>