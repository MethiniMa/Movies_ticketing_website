<?php
session_start();
include("connection.php");
include("function.php"); 

                 
if($_SERVER['REQUEST_METHOD'] == "POST")
{
  $username = $_POST['username'];
  $ps = $_POST['ps'];
  
  
  if(!empty($username))
  {
    if(!empty($ps)){
      
        $sql = "SELECT * FROM userlist WHERE UserName = '$username' limit 1";

        $result = mysqli_query($conn,$sql);

        if($result)
        {
            if($result && mysqli_num_rows($result) > 0)
            {
                $userData = mysqli_fetch_assoc($result);

                if($userData['PS'] == $ps)
                {
                    $_SESSION['UserName'] = $userData['UserName'];
                    header("Location: HuntSeat.php");
                    die;
                }else{
                    echo '<script type ="text/JavaScript">';  
                    echo 'alert("Password is incorrect!")';  
                    echo '</script>'; 
                }
            }else{
                echo '<script type ="text/JavaScript">';  
                echo 'alert("User does not existed, please sign up")';
                echo '</script>'; 
            }
        }
    }else{
        echo '<script type ="text/JavaScript">';  
        echo 'alert("Password cannot be empty")';
        echo '</script>'; 
        
      }
    }else{
        echo '<script type ="text/JavaScript">';  
        echo 'alert("Username cannot be empty")';
        echo '</script>'; 
        
      }

    }



?>

<!DOCTYPE html>
<html>
    <head>
        <title>Login.com</title>
        <style>
            body{
                background-color:darkred;
                
           }
            .login-box{
                width: 280px;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%,-50%);
                color: white;
            }
            .login-box h1{
                float: left;
                font-size: 40px;
                border-bottom: 6px solid #e0e7e7;
                margin-bottom: 50px;
                padding: 14px 0;
            }
            .textbox{
                width: 100%;
                overflow: hidden;
                font-size: 20px;
                border-bottom: 1px solid #e0e7e7;
                margin: 8px 0;
                padding: 8px 0;
            }
            .bt{
                width: 100%;
                background: none;
                border:2px solid  #e0e7e7;
                color: white;
                padding: 5px;
                font-size: 18px;
                cursor: pointer;
                margin: 12px 0;
            }
        </style>
    </head>

    <body>

        <div class="login-box">
            <h1 style="font-family: Arial, Helvetica, sans-serif;"><b>Login</b></h1>
            <a href="WebDesign.php">
            <img src="Image/home.png" width="50px" style="float:right; padding-top: 40px;">
            </a>
            
            <div class="textbox">

               <form method="POST">
                <b>Username: </b><br><br>
                <input type="text" name="username" placeholder="Username" style="padding:5px 90px 5px 20px;">
                <br><br>
                <b>Password: </b><br><br>
                <input type="password" name="ps" placeholder="Password" style="padding:5px 90px 5px 20px;">
                <br><br>
                <a href="SignUp.php">
                    <p style="color: white;"><u> Sign Up</u></p>
                </a>
                <a href="HuntSeat.php">
                    <input type="submit" class="bt" id="Login" value="Log In">
                </a>
               </form>
            </div>

        </div>
    </body>
</html>