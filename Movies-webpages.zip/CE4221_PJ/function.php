<?php

function check_login($conn)
{
    if(isset($_SESSION['UserName']))
    {
        $id = $_SESSION['UserName'];
        $query = "SELECT * FROM userlist WHERE UserName = '$id' limit 1";

        $result = mysqli_query($conn,$query);
        if($result && mysqli_num_rows($result) > 0)
        {
            $userData = mysqli_fetch_assoc($result);
            return $userData;
        }

    }

    header("Location: LoginPage.php");
    die;
}