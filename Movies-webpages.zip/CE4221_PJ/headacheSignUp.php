<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>headache.php</title>
</head>
<body>
<?php
include ("Connect1.php");
$Ph = $_POST['phone'];
$sql="SELECT * FROM userlist WHERE login_name ='$Ph'";
$result=mysqli_query($conn,$sql);
$nums=mysqli_num_rows($result);
if($nums > 0){
    echo '<script language="javascript">';
    echo 'alert("此學號已註冊過!");history.back()';
    echo '</script>';
}else{
    $insert ="INSERT INTO userlist (FirstName, LastName, Email, Phone, PS) 
    VALUES ('".$_POST['FName']."','".$_POST['LName']."','".$_POST['email']."','".$_POST['phone']."','".$_POST['password']."')";
    
    if($conn->query($insert) === TRUE){
        echo "<script>alert('註冊成功！請重新登入')</script>";
        
    }else {
         echo '<script language="javascript">';
         echo 'alert("出現錯誤!請重新註冊!");history.back()';
         echo '</script>';

    }
}
$conn->close();
?>
</body>
</html>