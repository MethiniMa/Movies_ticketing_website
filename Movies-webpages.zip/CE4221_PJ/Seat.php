<?php
session_start();
include("connection.php");
include("function.php"); 
$userData = check_login($conn);

?>

<!DOCTYPE html>
<html>
    <head>
       
        <title>AUBookingSeat.com</title>
        <style>
            body {
            font-family: "Montserrat", sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            background: linear-gradient(black,#722F37,rgb(107, 0, 0),black);
            color: #fff;
            margin: 0;
          }

          * {
            font-family: "Montserrat", sans-serif !important;
            box-sizing: border-box;
        }

          .movie-container {
            margin: 20px 0px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column
          }

          .movie-container select {
            appearance: none;
            -moz-appearance: none;
            -webkit-appearance: none;
            border: 0;
            padding: 5px 15px;
            margin-bottom: 40px;
            font-size: 14px;
            border-radius: 5px;
          }

          .container {
            perspective: 1000px;
            margin: 40px 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
          }

          .seat {
            background-color: #444451;
            height: 50px;
            width: 30px;
            margin: 8px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
          }

          .selected {
            background-color: #0081cb;
          }

          .occupied {
            background-color: #fff;
          }

          .seat:nth-of-type(12) {
            margin-right: 18px;
          }

          .seat:nth-last-of-type(12) {
            margin-left: 18px;
          }

          .seat:not(.occupied):hover {
            cursor: pointer;
            transform: scale(1.2);
          }

          .showcase .seat:not(.occupied):hover {
            cursor: default;
            transform: scale(1);
          }

          .showcase {
            display: flex;
            justify-content: space-between;
            list-style-type: none;
            background: rgba(0,0,0,0.1);
            padding: 5px 10px;
            border-radius: 5px;
            color: #777;
          }

          .showcase li {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 10px;
          }

          .showcase li small {
            margin-left: 2px;
          }

          .row {
            display: flex;
            align-items: center;
            justify-content: center;
          }

          .screen {
            background: #fff;
            height: 70px;
            width: 70%;
            margin: 15px 0;
            transform: rotateX(-45deg);
            box-shadow: 0 3px 10px rgba(255,255,255,0.7);
          }

          p.text {
            margin: 40px 0;
          }

          p.text span {
            color: #0081cb;
            font-weight: 600;
            box-sizing: content-box;
          }

          .credits a {
            color: #fff;
          }
          
        </style>

    </head>
    <body>

    <div class="movie-container">

      <select id="movie">
        <option value="250">250 per Seat</option>
      </select>
       <ul class="showcase">
        <li>
          <div class="seat"></div>
          <small>N/A</small>
        </li>
        <li>
          <div class="seat selected"></div>
          <small>Selected</small>
        </li>
        <li>
          <div class="seat occupied"></div>
          <small>Occupied</small>
        </li>    
      </ul>
     
      
      <div class="container">
        <div class="screen"></div>
        
        <div class="row">
          
            <p>F</p>
            <a><span class="seat">F1</span></a>
            <a><span class="seat">F2</span></a>
            <a><span class="seat">F3</span></a>
            <a><span class="seat">F4</span></a>
            <a><span class="seat">F5</span></a>
            <a><span class="seat">F6</span></a>
            <a><span class="seat">F7</span></a>
            <a><span class="seat">F8</span></a>
            <a><span class="seat">F9</span></a>
            <a><span class="seat">F10</span></a>
            
          </div>
          <div class="row">
            <P>E</P>
            <a><span class="seat">E1</span></a>
            <a><span class="seat">E2</span></a>
            <a><span class="seat">E3</span></a>
            <a><span class="seat">E4</span></a>
            <a><span class="seat">E5</span></a>
            <a><span class="seat">E6</span></a>
            <a><span class="seat">E7</span></a>
            <a><span class="seat">E8</span></a>
            <a><span class="seat">E9</span></a>
            <a><span class="seat">E10</span></a>
          </div>
          <div class="row">
            <P>D</P>
            <a><span class="seat">D1</span></a>
            <a><span class="seat">D2</span></a>
            <a><span class="seat">D3</span></a>
            <a><span class="seat">D4</span></a>
            <a><span class="seat">D5</span></a>
            <a><span class="seat">D6</span></a>
            <a><span class="seat">D7</span></a>
            <a><span class="seat">D8</span></a>
            <a><span class="seat">D9</span></a>
            <a><span class="seat">D10</span></a>
            
          </div>
          <div class="row">
            <p>C</p>
            <a><span class="seat">C1</span></a>
            <a><span class="seat">C2</span></a>
            <a><span class="seat">C3</span></a>
            <a><span class="seat">C4</span></a>
            <a><span class="seat">C5</span></a>
            <a><span class="seat">C6</span></a>
            <a><span class="seat">C7</span></a>
            <a><span class="seat">C8</span></a>
            <a><span class="seat">C9</span></a>
            <a><span class="seat">C10</span></a>
            
          </div>
          <div class="row">
            <p>B</p>
            <a><span class="seat">B1</span></a>
            <a><span class="seat">B2</span></a>
            <a><span class="seat">B3</span></a>
            <a><span class="seat">B4</span></a>
            <a><span class="seat">B5</span></a>
            <a><span class="seat">B6</span></a>
            <a><span class="seat">B7</span></a>
            <a><span class="seat">B8</span></a>
            <a><span class="seat">B9</span></a>
            <a><span class="seat">B10</span></a>
            
          </div>
          <div class="row">
            <p>A</p>
            <a><span class="seat">A1</span></a>
            <a><span class="seat">A2</span></a>
            <a><span class="seat">A3</span></a>
            <a><span class="seat">A4</span></a>
            <a><span class="seat">A5</span></a>
            <a><span class="seat">A6</span></a>
            <a><span class="seat">A7</span></a>
            <a><span class="seat">A8</span></a>
            <a><span class="seat">A9</span></a>
            <a><span class="seat">A10</span></a>
            
          </div>
        
        <p class="text">
          You have selected <span id="count">0</span> seats for the total price of Baht. <span id="total">0</span>
        </p>
        <br>
        <center>
          <a href="LoginPage.php">
            <input type="button" id="button1" value="Confirm" 
            style="border-radius:14px; background-color:gold; width: 100px; height: 50px;"></button>
          </a>
        </center>
      </div>
    </div>
    <script src="Seat.js"></script>
    </body>
</html>