var list = document.getElementById('valueList');
var text = '<span> You have selected: </span>';
var listArray = [];

var count = 0;
var total;
var text1 = '<span> You have selected: </span> ';
var text2 = '<span> Total: </span>';
var seatinfo = document.getElementById('seatinfo');

var checkboxes = document.querySelectorAll('.checkbox');

for(var checkbox of checkboxes){
    checkbox.addEventListener('click' ,function(){
        if(this.checked == true){
            listArray.push(this.value);
            valueList.innerHTML = text + listArray.join(' / ');
            seatinfo.innerHTML = listArray.join(' / ');
            count++;
            total = count*250;
            document.getElementById('countList').innerHTML = text1 + count + " seats";
            document.getElementById('totalList').innerHTML = text2 + total + " baht";
            

        }else{
            listArray = listArray.filter(e => e !== this.value);
            valueList.innerHTML = text + listArray.join(' / ');
            seatinfo.innerHTML = listArray.join(' / ');
            count--;
            total = count*250;
            document.getElementById('countList').innerHTML = text1 + count + " seats";
            document.getElementById('totalList').innerHTML = text2 + total + " baht";
            

        }
    })
}


