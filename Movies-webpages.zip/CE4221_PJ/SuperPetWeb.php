<?php
session_start();
include("connection.php");
include("function.php"); 
$userData = check_login($conn);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body{
                background: linear-gradient(black,darkred,black);
            }
            /* card */
            header .cards{
                margin: auto;
                display: flex;
                align-items: center;
                justify-content: space-between;
            }

            header .cards .card{
                width: 220px;
                height: 300px;
                margin: 0px 5px;
                border-radius: 15px;
                
            }

            header .cards .card img{
                width: 100%;
                height: 100%;
                border-radius: 15px;
                transition: all 200ms ease-in-out;
            }

            header .cards .card img:hover{
                transform: scale(1.1);
                cursor: pointer;
            }

            header .cards .card .heading1{
                color: white;
                line-height: 1;
                
            }

            h4 {
            font-size: 24px;
            color: Gold;
            font-style: normal;
            font-weight: bold;
            }
            
            h1 {
            font-size: 24px;
            color: Gold;
            font-style: normal;
            font-weight: bold;
            }


            p1 {
            font-size: 15px;
            color: Gold;
            font-style: normal;
            font-weight: bold;
            }

            p2 {
            font-size: 18px;
            color: whitesmoke;
            font-style: normal;
            font-weight:lighter;
            }

            .center {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 60%;
            }

            .button {
            border: none;
            color: black;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            }

            .button1 {
            background-color: gold;
            border-radius: 12px;
            }

            .button1:hover {
            background-color: darkred;
            color: white;
            }

            a { 
            text-decoration: none; 
            color: white;
            }
        </style>
    </head>
    <body>
        <div style="background-color: black; font-size: 20px; font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        padding: 30px; margin: 30px; color: white;">
             <img src="https://cdn-icons-png.flaticon.com/512/1169/1169097.png" width="120px" style="padding-left:5px;">&emsp;&emsp;
             
             <div style="float:right; margin-top:25px;margin-right:100px">
             <a href="WebDesign.php">
                <span id="Op1" onmouseover="document.getElementById('Op1').style.fontSize='22px';"
                onmouseout="document.getElementById('Op1').style.fontSize='20px';"> HOME &emsp;&emsp; </span>
             </a>

              <a href="Movie.html">
                <span id="Op2" onmouseover="document.getElementById('Op2').style.fontSize='22px';"
              onmouseout="document.getElementById('Op2').style.fontSize='20px';"> MOVIE &emsp;&emsp;</span>
             </a>

             <a href="Cinema.html">
              <span id="Op3" onmouseover="document.getElementById('Op3').style.fontSize='22px';"
              onmouseout="document.getElementById('Op3').style.fontSize='20px';"> CINEMA &emsp;&emsp;</span></a>
              
              <span id="Op4" onmouseover="document.getElementById('Op4').style.fontSize='22px';"
              onmouseout="document.getElementById('Op4').style.fontSize='20px';"> INVESTOR RELATIONS &emsp;&emsp;</span>

              <a href="News.html">
                <span id="Op5" onmouseover="document.getElementById('Op5').style.fontSize='22px';"
              onmouseout="document.getElementById('Op5').style.fontSize='22px';"> NEWS &emsp;&emsp;</span>
              </a>

              <a href="Promotion.html">
                <span id="Op6" onmouseover="document.getElementById('Op6').style.fontSize='22px';"
              onmouseout="document.getElementById('Op6').style.fontSize='20px';"> PROMOTION &emsp;&emsp;</span>
              </a>

              <a href="FQAs.html">
              <span id="Op7" onmouseover="document.getElementById('Op7').style.fontSize='22px';"
              onmouseout="document.getElementById('Op7').style.fontSize='20px';"> FQAs &emsp;&emsp;</span>
              </a>

              <img src="https://cdn-icons-png.flaticon.com/512/1296/1296902.png" width="40px" style="padding-right: 10px;">&emsp;
             </div>
        </div><br>
        <br>
        <header>
            <div class="cards">
                <div class="card">
                    <img src="Image/Superpet.jpg">   
                    <h4> DC League of Super-Pets </h4>
                    <p2> 105 mins | Adventure/Sci-fi</p2><br>
                    <br>
                    <a href="SuperPetLog.php">
                        <button class="button button1">Buy Ticket</button>
                    </a>
                        
                </div>
                <iframe class="center" width="500" height="400" src="https://www.youtube.com/embed/1jkw2JPCl18">
                </iframe>
            
            </div><br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>

            <h1> Synopsis </h1>
            <p2>When Superman and the rest of the Justice League are kidnapped, 
                Krypto must convince a rag-tag shelter pack--Ace the hound, PB the potbellied pig, 
                Merton the turtle and Chip the squirrel--to master their own newfound powers and help him rescue the superheroes..</p2><br>
                <br>
                <br>
        </header>
    </body>
</html>