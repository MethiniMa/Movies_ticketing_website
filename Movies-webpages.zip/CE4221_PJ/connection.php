<!DOCTYPE html>
<html>
    <head>
        <title>Test connect</title>
    </head>
    <body>
        <?php
        $conn = new mysqli('localhost','root','','ce4221');
        if($conn->connect_error){
            die("Connection failed: " . $conn->connect_error);
        }
        ?>
    </body>
</html>